﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sample
{
    public class Sample
    {
        public string GetDate()
        {
            Form1 f = new Form1();
            return f.ShowForm();
        }
    }
}
