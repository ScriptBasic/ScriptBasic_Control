/* FILE: buildnum.c
HEADER: buildnum.h
This file was automatically created by newbuild.bas
Each time a new build is to be released this program
is ran and it increments the build number.
TO_HEADER:

#ifndef SCRIPTBASIC_BUILD
#define SCRIPTBASIC_BUILD 1
#endif
*/
