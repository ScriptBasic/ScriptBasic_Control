/*
mynotimp.h
*/
#ifndef __MYNOTIMP_H__
#define __MYNOTIMP_H__ 1
#ifdef  __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif
