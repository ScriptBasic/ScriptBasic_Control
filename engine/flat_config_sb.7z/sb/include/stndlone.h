/*
stndlone.h
*/
#ifndef __STNDLONE_H__
#define __STNDLONE_H__ 1
#ifdef  __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif
