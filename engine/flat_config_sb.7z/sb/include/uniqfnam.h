/*
uniqfnam.h
*/
#ifndef __UNIQFNAM_H__
#define __UNIQFNAM_H__ 1
#ifdef  __cplusplus
extern "C" {
#endif

#define UNIQ_FILE_NAME_LENGTH 32

/*FUNDEF*/

void uniqfnam(char *pszInputFileName,
              char *pszOutputFileName);
/*FEDNUF*/
#ifdef __cplusplus
}
#endif
#endif
