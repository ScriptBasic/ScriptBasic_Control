/*

FILE: mynotimp.c

This file is the place to store your #define NOTIMP_xxxx 1
macros. Use #undef and then #define to redefine any of the macros
that you do not want the corresponding command been compiled into
ScriptBasic.

This file is included by notimp.h

Because notimp.h is automatically generated it is better not to edit
that file. Instead place redefines here.

TO_HEADER:

*/
